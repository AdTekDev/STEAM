console.log("xin chao !");
